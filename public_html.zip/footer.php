<!-- Placed js at the end of the document so the pages load faster -->
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/menuzord.js"></script>
    <script src="js/jquery.flexslider-min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.isotope.js"></script>
    <script src="js/imagesloaded.js?1"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/smooth.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/imagesloaded.js"></script>
    <!--common scripts-->
    <script src="js/scripts.js?6"></script>
    <script src="js/jquery_form.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/4.4.0/bootbox.min.js"></script>
    <script src="lg/js/lightbox.js"></script>
</body>
</html>