							<div class="text-center" >
                                <div class="heading-title text-center">
                                    <span class="text-uppercase"><a href="./index.php" >HOME</a></span>
                                     <span class="text-uppercase">|</span>
                                     <span class="text-uppercase"><a href="./photo_upload.php" >PHOTO UPLOAD</a></span>
                                </div>
                            </div>