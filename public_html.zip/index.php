<?php include("header.php");?>  
<div id="tb-preloader">
    <div class="tb-preloader-wave"></div>
</div>
<div class="wrapper">
        <section class="body-content">
            <div class=" page-content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <?php include("menu.php");?>
                        </div>
                        <div id ="content"></div> 
                    </div>
                </div>
            </div>
        </section>   
    </div>
<?php include("load_footer_items.php");?>